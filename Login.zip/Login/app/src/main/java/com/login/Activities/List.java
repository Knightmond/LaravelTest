package com.login.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.login.Adapters.CoordinatesAdapter;
import com.login.Clases.Coordinates;
import com.login.R;

import java.util.ArrayList;

public class List extends AppCompatActivity {

    ListView listView;
    String TAG = "FirebaseList";
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        listView = findViewById(R.id.listViewCoordinates);

        loadCoordinates();
    }

    private void loadCoordinates(){
        db.collection("Coordinates")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {

                            ArrayList<Coordinates> arrayList = new ArrayList<>();

                            for (QueryDocumentSnapshot document : task.getResult()) {
                                //Log.d(TAG, String.valueOf(document.get("latitude")) + " - " + document.getId());
                                arrayList.add(new Coordinates(
                                        document.getId(),
                                        document.getDate("date "),
                                        Float.parseFloat(String.valueOf(document.get("latitude"))),
                                        Float.parseFloat(String.valueOf(document.get("longitude")))
                                ));
                            }

                            CoordinatesAdapter coordinatesAdapter =
                                    new CoordinatesAdapter(arrayList, List.this, listView);
                            listView.setAdapter(coordinatesAdapter);

                        } else {
                            Log.w(TAG, "Error getting documents.", task.getException());
                        }
                    }
                });
    }
}