package com.login.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.login.R;

public class SignUp extends AppCompatActivity {

    TextView goToLogin;
    Button btnSignup;
    EditText txtCorreo,txtPassword;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        goToLogin = findViewById(R.id.txtViewLogin);
        btnSignup = findViewById(R.id.btnSignUp);
        txtCorreo = findViewById(R.id.txtCorreo);
        txtPassword = findViewById(R.id.txtContrasena);
        mAuth = FirebaseAuth.getInstance();

        goToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SignUp.this, Login.class));
            }
        });

        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signUpUser();
            }
        });
    }

    private void signUpUser() {
        String email = txtCorreo.getText().toString().trim();
        String password = txtPassword.getText().toString().trim();

        mAuth.createUserWithEmailAndPassword(email, password)
        .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    // Sign in success, update UI with the signed-in user's information
                    FirebaseUser user = mAuth.getCurrentUser();
                    Log.i("signup","Se creo un usuario correctamente");
                    updateUI(user);
                } else {
                    // If sign in fails, display a message to the user.
                    Log.e("signup","No se pudo crear al usuario");
                    updateUI(null);
                }
            }
        });
    }

    private void updateUI(FirebaseUser response) {
        if(response != null) {
            startActivity(new Intent(SignUp.this,Login.class));
            Toast.makeText(SignUp.this,"Registro Exitoso",
                    Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(SignUp.this,"El registro se curifeo xd",
                    Toast.LENGTH_LONG).show();
        }
    }
}