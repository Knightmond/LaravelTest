package com.login.Adapters;

import android.database.DataSetObserver;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.login.Activities.List;
import com.login.Clases.Coordinates;
import com.login.R;

import java.util.ArrayList;

public class CoordinatesAdapter implements ListAdapter {

    ArrayList<Coordinates> arrayList;
    List list;
    ListView listView;
    FirebaseFirestore db;
    String TAG = "SAS";

    public CoordinatesAdapter(ArrayList<Coordinates> arrayList, List list, ListView listView) {
        this.arrayList = arrayList;
        this.list = list;
        this.listView = listView;

        db = FirebaseFirestore.getInstance();
    }

    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }

    @Override
    public boolean isEnabled(int i) {
        return false;
    }

    @Override
    public void registerDataSetObserver(DataSetObserver dataSetObserver) {

    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {

    }

    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        if (view == null){
            LayoutInflater layoutInflater = LayoutInflater.from(list);

            view = layoutInflater.inflate(R.layout.coordinates_list_item, null);
        }

        TextView latitudeAndLongitude = view.findViewById(R.id.txtLatitudeLongitude);

        TextView date = view.findViewById(R.id.txtDate);

        latitudeAndLongitude.setText("" + arrayList.get(position).getLatitude()
                + ", " + arrayList.get(position).getLongitude());

        java.text.DateFormat dateFormat = DateFormat.getLongDateFormat(list);
        java.text.DateFormat timeFormat = DateFormat.getTimeFormat(list);

        //Log.d("cosalog" , "" + arrayList.get(position).getDate());

        date.setText("" + dateFormat.format(arrayList.get(position).getDate())
                + " " + timeFormat.format(arrayList.get(position).getDate()));

        ImageButton delete = view.findViewById(R.id.ibtnDelete);

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.collection("Coordinates").document(arrayList.get(position).getId())
                        .delete()
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                arrayList.remove(position);
                                if (arrayList.size() > 0){
                                    CoordinatesAdapter coordinatesAdapter =
                                            new CoordinatesAdapter(arrayList, list, listView);
                                    listView.setAdapter(coordinatesAdapter);
                                } else {
                                    listView.invalidateViews();
                                }

                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(list, "Ocurrio un error al eliminar", Toast.LENGTH_SHORT).show();
                            }
                        });

                /*if (arrayList.size() > 0){
                    CoordinatesAdapter coordinatesAdapter =
                            new CoordinatesAdapter(arrayList, list, listView);
                    listView.setAdapter(coordinatesAdapter);
                } else {
                    listView.invalidateViews();
                }*/



            }
        });

//        view.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // que nos envie a Google maps
//                /*Uri gmmIntentUri = Uri.parse("geo:" + arrayList.get(position).getLatitude() + "," +arrayList.get(position).getLongitude());
//                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
//                mapIntent.setPackage("com.google.android.apps.maps");
//                if (mapIntent.resolveActivity(getPackageManager()) != null) {
//                    startActivity(mapIntent);
//                }*/
//                Intent intent = new Intent(android.content.Intent.ACTION_VIEW,
//                        Uri.parse("geo:" + arrayList.get(position).getLatitude() + "," +arrayList.get(position).getLongitude()));
//                list.startActivity(intent);
//            }
//        });

        return view;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public int getViewTypeCount() {
        return arrayList.size();
    }

    @Override
    public boolean isEmpty() {
        return false;
    }
}
