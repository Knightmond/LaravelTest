<?php return array (
  'cursos.cursos-index' => 'App\\Http\\Livewire\\Cursos\\CursosIndex',
  'pruebas-index' => 'App\\Http\\Livewire\\PruebasIndex',
);