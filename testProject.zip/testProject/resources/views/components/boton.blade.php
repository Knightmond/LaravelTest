<button type="button" class="btn btn-primary">Primary</button>
