<div>
    <h1>Hey Curifeoooooooooooooooooooo {{ $nombre }}</h1>
    <label for="">Username</label>
    <input type="text" wire:model="nombre">
    <button wire:click="incrementar" class="btn btn-primary"> + </button>
    <button wire:click="decrementar" class="btn btn-danger"> - </button>
    <p>{{$valor}}</p>
</div>
