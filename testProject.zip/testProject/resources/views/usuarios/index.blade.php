@extends("layouts.template")

@section("seccion")
<h1>Hola, soy {{$nombre}}, tengo {{$edad}} años</h1>
@endsection
