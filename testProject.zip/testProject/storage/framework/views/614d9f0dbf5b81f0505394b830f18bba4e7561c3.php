<div>
    <h1>Hey Curifeoooooooooooooooooooo <?php echo e($nombre); ?></h1>
    <label for="">Username</label>
    <input type="text" wire:model="nombre">
    <button wire:click="incrementar" class="btn btn-primary"> + </button>
    <button wire:click="decrementar" class="btn btn-danger"> - </button>
    <p><?php echo e($valor); ?></p>
</div>
<?php /**PATH C:\Users\DS-22\Desktop\testProject\resources\views/livewire/pruebas-index.blade.php ENDPATH**/ ?>