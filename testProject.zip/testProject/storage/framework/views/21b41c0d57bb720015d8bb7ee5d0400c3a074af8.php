<?php $__env->startSection("seccion"); ?>
<h1>Hola, soy <?php echo e($nombre); ?>, tengo <?php echo e($edad); ?> años</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DS-22\Desktop\testProject\resources\views/usuarios/index.blade.php ENDPATH**/ ?>